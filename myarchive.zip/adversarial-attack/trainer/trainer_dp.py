import os
import time
import json
import numpy as np
import random
import argparse
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader
from transformers import AdamW, \
    get_cosine_schedule_with_warmup, \
    get_linear_schedule_with_warmup, \
    get_polynomial_decay_schedule_with_warmup
from torch import nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, recall_score, precision_score, classification_report, roc_curve, auc, f1_score, recall_score, precision_score, balanced_accuracy_score
import matplotlib.pyplot as plt
from datasets import SafetyDataset
from models import SafetyModel
from data_compression import draw
from tqdm import tqdm
import wandb
from accelerate import Accelerator, DistributedDataParallelKwargs
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"
os.environ['PYTHONWARNINGS'] = 'ignore:semaphore_tracker:UserWarning'
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# nohup python3 -m torch.distributed.launch --nproc_per_node=4 --nnodes=1 trainer.py >weights/20210627_1_test/logs.out 2>&1 &

# sudo python3 -m torch.distributed.launch --nproc_per_node=4 --master_port 29522 trainer.py --local_rank -1 

parser = argparse.ArgumentParser()
parser.add_argument("--local_rank", type=int, default=-1)
parser.add_argument("--save_path", type=str, default=None)
parser.add_argument("--mode", type=str, default="train")
args = parser.parse_args()


ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
accelerator = Accelerator(fp16=True, kwargs_handlers=[ddp_kwargs])
device = accelerator.device
try:
    args.local_rank = dist.get_rank()
    word_size = dist.get_world_size()
    print("args.local_rank", args.local_rank)
except:
    print("no dist used")
    word_size = 1


def set_seed(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

# class PGD():
#     def __init__(self, model):
#         self.model = model
#         self.emb_backup = {}
#         self.grad_backup = {}

#     def attack(self, epsilon=1., alpha=0.3, emb_name='word_embeddings.', is_first_attack=False):
#         # emb_name这个参数要换成你模型中embedding的参数名
#         for name, param in self.model.named_parameters():
#             if param.requires_grad and emb_name in name:
#                 if is_first_attack:
#                     self.emb_backup[name] = param.data.clone()
#                 norm = torch.norm(param.grad)
#                 if norm != 0:
#                     r_at = alpha * param.grad / norm
#                     param.data.add_(r_at)
#                     param.data = self.project(name, param.data, epsilon)

#     def restore(self, emb_name='word_embeddings.'):
#         # emb_name这个参数要换成你模型中embedding的参数名
#         for name, param in self.model.named_parameters():
#             if param.requires_grad and emb_name in name: 
#                 assert name in self.emb_backup
#                 param.data = self.emb_backup[name]
#         self.emb_backup = {}
        
#     def project(self, param_name, param_data, epsilon):
#         r = param_data - self.emb_backup[param_name]
#         if torch.norm(r) > epsilon:
#             r = epsilon * r / torch.norm(r)
#         return self.emb_backup[param_name] + r
        
#     def backup_grad(self):
#         for name, param in self.model.named_parameters():
#             if param.requires_grad:
#                 if param.grad != None:
#                     self.grad_backup[name] = param.grad.clone()
    
#     def restore_grad(self):
#         for name, param in self.model.named_parameters():
#             if param.requires_grad:
#                 if param.grad != None:
#                     param.grad = self.grad_backup[name]
                
seed = 42
set_seed(seed)

def evaluate(model, datas, device, dataloader, batch_size=32, num_workers=4, len_stats=False, evaluate=False):
    model.eval()
    if evaluate: datas.eval()
    val_true, val_pred, val_score = [], [], []
    len_ = []
    with torch.no_grad():
        for idx, (ids, att, y, length) in (enumerate(tqdm(dataloader))):
            y_pred = model((ids.to(device), att.to(device)))
            
            y = y.to(device)
            all_y_pred = accelerator.gather(y_pred.logits)
            all_y = accelerator.gather(y)
            
            all_y_score = nn.functional.softmax(all_y_pred, dim=1).cpu().numpy()[:,1].tolist()
            all_y_pred = torch.argmax(all_y_pred, dim=1).detach().cpu().numpy().tolist()
            val_score.extend(all_y_score)
            val_pred.extend(all_y_pred)
            val_true.extend(all_y.squeeze().cpu().numpy().tolist())
            if len_stats: len_.extend([int(leng) for leng in length])
                
    if len_stats:
        val_score = np.array(val_score)
        val_pred = np.array(val_pred)
        val_true = np.array(val_true)
        len_ = np.array(len_)
        # positive is white, zero is black
        tp = len_[(val_true==val_pred) & (val_true==1)] # actual=white
        tn = len_[(val_true==val_pred) & (val_true==0)] # actual=black
        fp = len_[(val_true!=val_pred) & (val_true==0)] # pred=white, actual=black
        fn = len_[(val_true!=val_pred) & (val_true==1)] # pred=black, actual=white
        print(f"tp len {len(tp)}")
        print(f"tn len {len(tn)}")
        print(f"fp len {len(fp)}")
        print(f"fn len {len(fn)}")
        draw(min(tp), max(tp), list(tp), title=f"tp", fig_name=f"tp")
        draw(min(tn), max(tn), list(tn), title=f"tn", fig_name=f"tn")
        draw(min(fp), max(fp), list(fp), title=f"fp", fig_name=f"fp")
        draw(min(fn), max(fn), list(fn), title=f"fn", fig_name=f"fn")
        with open("tp", "w+") as file:
            file.write(" ".join(list(map(str, tp))))
        with open("tn", "w+") as file:
            file.write(" ".join(list(map(str, tn))))
        with open("fp", "w+") as file:
            file.write(" ".join(list(map(str, fp))))
        with open("fn", "w+") as file:
            file.write(" ".join(list(map(str, fn))))
    if evaluate: datas.phrase="train"
    model.train()
    return val_true, val_pred, val_score

def save_roc(val_pred, val_true):
    fpr, tpr, _ = roc_curve(val_true, val_score)
    roc_auc = auc(fpr, tpr)
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange',
             lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Safety')
    plt.legend(loc="lower right")
    plt.savefig("roc.png")


def safety_trainer(epochs=20,
                   batch_size=32,
#                    reformer_model_path="../../pretrains/model_20210726_tok_20210709_checkpoint-99825",
                   reformer_model_path=None,
                   reformer_tokenizer_path="../../tokenizers/tokenizer_20210709",
                   black_data_path=["../../datas/mini_data/black_log_processed.txt"],
                   white_data_path=["../../datas/mini_data/white_log_processed.txt"],
                   test_black_data_path=["../../datas/test_data/black_log_processed.txt"],
                   test_white_data_path=["../../datas/test_data/white_log_processed.txt"],
                   save_path="./check_points",
                   pre_trained_model=None,
                   start_epoch=0,
                   num_workers=4,
                   num_labels=2,
                   flag_get_idx=False,
                   hidden_dropout_prob=0.5,
                   hidden_size=768,
                   print_parm=1,
                   white_ratio=0.02,
                   maxlen=512,
                   num_hidden_layers=2,
                   len_stats=False,
                   lr=5e-5,
                   weight_decay=1e-3,
                   position_embedding_type="potato",
                   hidden_act="gelu",
                   file_name="Unamed",
                   init_sample=0.1,
                   sample_epoch=0.8,
                   degree=2,
                   overwrite_config=False):


    trainer_config = {"epochs": epochs,
                      "batch_size": batch_size,
                      "reformer_model_path": reformer_model_path,
                      "reformer_tokenizer_path": reformer_tokenizer_path,
                      "black_data_path": black_data_path,
                      "white_data_path": white_data_path,
                      "save_path": save_path,
                      "pre_trained_model": pre_trained_model,
                      "start_epoch": start_epoch,
                      "num_workers": num_workers,
                      "num_labels": num_labels,
                      "flag_get_idx": flag_get_idx,
                      "hidden_dropout_prob": hidden_dropout_prob,
                      "hidden_size": hidden_size,
                      "print_parm": print_parm,
                      "white_ratio": white_ratio,
                      "maxlen": maxlen,
                      "lr": lr,
                      "weight_decay": weight_decay,
                      "test_black_data_path": test_black_data_path,
                      "test_white_data_path": test_white_data_path,
                      "name": "trainer.py",
                      "location": str(os.uname())
                      }
    
    model_config = {"reformer_model_path": reformer_model_path,
                    "reformer_tokenizer_path": reformer_tokenizer_path,
                    "maxlen": maxlen,
                    "vocab_size": 10000,
                    "max_position_embeddings": maxlen+2,
                    "num_attention_heads": 12,
                    "num_hidden_layers": num_hidden_layers,
                    "type_vocab_size": 1,
                    "hidden_dropout_prob": hidden_dropout_prob,
                    "hidden_size": hidden_size,
                    "num_labels": num_labels,
                    "position_embedding_type": position_embedding_type,
                    "hidden_act": hidden_act,
                    "overwrite_config": overwrite_config,
                    }

    if not os.path.exists(save_path):
        try:
            os.mkdir(save_path)
        except:
            pass
    
    model = SafetyModel(**model_config)
    model.load_weights(pre_trained_model)

    dataset_config = {
        "black_data_path": black_data_path,
        "white_data_path": white_data_path,
        "tokenizer": model.tokenizer,
        "maxlen": maxlen,
        "phase": "train",
        "flag_get_idx": flag_get_idx,
        "white_ratio": white_ratio,
        "len_stats": len_stats,
        "init_sample": init_sample,
    }

    train_data = SafetyDataset(**dataset_config)
    train_dataloader = DataLoader(train_data, batch_size=batch_size,
                                  shuffle=True, num_workers=num_workers)
    
    test_dataset_config = dataset_config.copy()
    test_dataset_config["black_data_path"] = test_black_data_path
    test_dataset_config["white_data_path"] = test_white_data_path
    test_dataset_config["phase"] = "eval"
    test_data = SafetyDataset(**test_dataset_config)
    test_dataloader = DataLoader(test_data, batch_size=batch_size,
                              shuffle=True, num_workers=num_workers)
    
    dataset_config["tokenizer"] = reformer_tokenizer_path

    config_dict = {
        "trainer_config": trainer_config,
        "model_config": model_config,
        "dataset_config": dataset_config,
    }
    
    if args.local_rank == 0: 
        run=wandb.init(name=file_name, entity="asdf1473", project="safety", config=config_dict)
        print(os.path.join(save_path, "config.json"))
        with open(os.path.join(save_path, "config.json"), "w+") as f:
            json.dump(config_dict, f, indent=4)
            
    dataset_config["smiles_tokenizer"] = model.tokenizer

    optimizer = AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    model, optimizer, train_dataloader, test_dataloader = accelerator.prepare(
        model, optimizer, train_dataloader, test_dataloader)
    
#     scheduler = get_polynomial_decay_schedule_with_warmup(optimizer, num_warmup_steps=len(train_dataloader)/init_sample,
#                                                           num_training_steps=train_data.get_total_step(c_epoch=start_epoch, t_epoch=epochs))
#     print(["here",(epochs-start_epoch)*len(train_dataloader)/2/init_sample, train_data.get_total_step(c_epoch=start_epoch, t_epoch=epochs)])
    
    scheduler = get_polynomial_decay_schedule_with_warmup(optimizer, num_warmup_steps=len(train_dataloader),
                                                          num_training_steps=(epochs-start_epoch)*len(train_dataloader)/2/init_sample)
    
#     if pre_trained_model is not None and os.path.exists(pre_trained_model.replace(".pth", ".checkpoint")):
#         dict_tmp = torch.load(
#             pre_trained_model.replace(".pth", ".checkpoint"))
#         optimizer.load_state_dict(dict_tmp["optimizer"])
#         scheduler.load_state_dict(dict_tmp["scheduler"])
#         start_epoch= dict_tmp["epoch"]   
    
#     pgd = PGD(accelerator.unwrap_model(model))
#     K = 3
    
    for epoch in range(start_epoch, epochs):
        train_dataloader.dataset.update_competence(epoch, epochs, sample_epoch, degree)
        torch.cuda.empty_cache()
        train_loss_sum = 0.0
        start = time.time()
        optimizer.zero_grad()
        for idx, batch in enumerate(tqdm(train_dataloader)):
            safety_ids_tensor, safety_mask_tensor, labels, _ = batch
            safety_tensor = (safety_ids_tensor.to(device),
                             safety_mask_tensor.to(device))
            total_loss = model(safety_tensor, labels.to(device), device)[0]
            accelerator.backward(total_loss)
            
#             pgd.backup_grad()
#             for t in range(K):
#                 pgd.attack(is_first_attack=(t==0)) # 在embedding上添加对抗扰动, first attack时备份param.data
#                 if t != K-1:
#                     optimizer.zero_grad()
#                 else:
#                     pgd.restore_grad()
#                 loss_adv = model(safety_tensor, labels.to(device), device)[0]
#                 accelerator.backward(loss_adv) # 反向传播，并在正常的grad基础上，累加对抗训练的梯度
#             pgd.restore() # 恢复embedding参数
            
            if (idx+1) % int(128/batch_size) == 0:
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
            train_loss_sum += total_loss.item()
            if args.local_rank % 4 == 0 and (idx + 1) % (len(train_dataloader)//5) == 0:
                print("Epoch {:04d} | Step {:04d}/{:04d} | Loss {:.4f} | Time {:.4f}".format(
                    epoch+1, idx+1, len(train_dataloader),
                    train_loss_sum/(idx+1),
                    time.time() - start))
                print("Learning rate = {}".format(
                    optimizer.state_dict()['param_groups'][0]['lr']))
        if args.local_rank == 0 and epoch % print_parm == 0:
            name = file_name+"_{}_loss_{}.pth".format(epoch,
                                                                 round(train_loss_sum/len(train_dataloader),
                                                                       8))
            torch.save(accelerator.unwrap_model(model).state_dict(),
                       os.path.join(save_path, name))
            checkpoint_dict = {
                "epoch": epoch,
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
            }
            torch.save(checkpoint_dict, os.path.join(save_path, name.replace(".pth", ".checkpoint")))
            
        val_true1, val_pred1, val_score1 = evaluate(model=accelerator.unwrap_model(model), datas=train_data, dataloader=train_dataloader,  device=device, evaluate=True)
        val_true2, val_pred2, val_score2 = evaluate(model=accelerator.unwrap_model(model), datas=test_data, dataloader=test_dataloader,  device=device, evaluate=True) # Use only 1/5 of vali and test data to test
        if args.local_rank == 0:
            print(classification_report(val_true1, val_pred1))
            print(classification_report(val_true2, val_pred2))
            wandb.log({"epoch": epoch, 
                       "loss": train_loss_sum/len(train_dataloader),
                       "roc_vali":roc_auc_score(val_true1, val_score1), 
                       "acc_vali":accuracy_score(val_true1, val_pred1),
                       "balanced_acc_vali":balanced_accuracy_score(val_true1, val_pred1),
                       "f1_score_vali":f1_score(val_true1, val_pred1),
                       "roc_test":roc_auc_score(val_true2, val_score2), 
                       "acc_test":accuracy_score(val_true2, val_pred2),
                       "balanced_acc_test":balanced_accuracy_score(val_true2, val_pred2),
                       "f1_score_test":f1_score(val_true2, val_pred2),
                })
        dist.barrier()
    if args.local_rank == 0: run.finish()        

if __name__ == "__main__":
    if args.mode == "train":  
        safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, file_name=f"data=mini_data, pretrain=None, init=1")
#         set_seed(1)
#         for b in [32]:
#             safety_trainer(epochs=20, batch_size=b, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, file_name=f"init=1 batch_size{b}")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=0.1, file_name=f"new_data")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, num_hidden_layers=3, file_name=f"num_hidden_layers=3")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=0.1, sample_epoch=0.5, file_name=f"sample_epoch=0.5")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=0.1, degree=4, file_name=f"degree=4")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, reformer_model_path=None, black_data_path=["../../datas/data_headnoambi/black_log_processed.txt"], white_data_path=["../../datas/data_headnoambi/white_log_processed.txt"], file_name=f"init=1, pretrain=None, data_headnoambi")
#         safety_trainer(epochs=20, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, reformer_model_path=None, black_data_path=["../../datas/data_headset/black_log_processed.txt"], white_data_path=["../../datas/data_headset/white_log_processed.txt"], file_name=f"data_headset")
#         safety_trainer(epochs=20, batch_size=64, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, reformer_model_path=None, black_data_path=["../../datas/data_tailset/black_log_processed.txt"], white_data_path=["../../datas/data_tailset/white_log_processed.txt"], file_name=f"data_tailset")
#         safety_trainer(epochs=20, batch_size=64, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, reformer_model_path=None, black_data_path=["../../datas/data_segset/black_log_processed.txt"], white_data_path=["../../datas/data_segset/white_log_processed.txt"], file_name=f"data_segset")
#         safety_trainer(epochs=20, batch_size=64, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, reformer_model_path=None, black_data_path=["../../datas/data_seg/black_log_processed.txt"], white_data_path=["../../datas/data_seg/white_log_processed.txt"], file_name=f"data_seg")
#         seed = 42
#         set_seed(seed)
#         for init_sample in [1, 0.9, 0.8]:
#             for i in range(5,9):
#                 set_seed(i)
#                 safety_trainer(epochs=10, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, position_embedding_type="abs", init_sample=init_sample, file_name=f"{i}")

        
    else:
        model_test()

        
        
