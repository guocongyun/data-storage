import os
import time
import json
import numpy as np
import random
import argparse
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader
from transformers import AdamW, \
    get_cosine_schedule_with_warmup, \
    get_linear_schedule_with_warmup, \
    get_polynomial_decay_schedule_with_warmup
from torch import nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, recall_score, precision_score, classification_report, roc_curve, auc, f1_score, recall_score, precision_score, balanced_accuracy_score
import matplotlib.pyplot as plt
from tqdm import tqdm
import wandb
from accelerate import Accelerator, DistributedDataParallelKwargs
import glob 

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
os.environ['PYTHONWARNINGS'] = 'ignore:semaphore_tracker:UserWarning'
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# nohup python3 -m torch.distributed.launch --nproc_per_node=4 --nnodes=1 trainer.py >weights/20210627_1_test/logs.out 2>&1 &

# sudo python3 -m torch.distributed.launch --nproc_per_node=8 --master_port 29522 evaluator.py --local_rank -1 

parser = argparse.ArgumentParser()
parser.add_argument("--local_rank", type=int, default=-1)
parser.add_argument("--save_path", type=str, default=None)
parser.add_argument("--mode", type=str, default="train")
args = parser.parse_args()


ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
accelerator = Accelerator(fp16=True, kwargs_handlers=[ddp_kwargs])
device = accelerator.device
try:
    args.local_rank = dist.get_rank()
    word_size = dist.get_world_size()
    print("args.local_rank", args.local_rank)
except:
    print("no dist used")
    word_size = 1


def set_seed(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
                
seed = 42
set_seed(seed)

def evaluate(model, device, dataloader, batch_size=32, num_workers=2, len_stats=False, evaluate=False):
    model.eval()
    val_true, val_pred, val_score = [], [], []
    val_true2, val_pred2, val_score2 = [], [], []
    len_ = []
    with torch.no_grad():
        for idx, (ids, att, y, z, length) in (enumerate(tqdm(dataloader))):
            y_pred, z_pred = model.forward_eval((ids.to(device), att.to(device)))
            
            y = y.to(device)
            all_y_pred = accelerator.gather(y_pred)
            all_y = accelerator.gather(y)
            
            z = z.to(device)
            all_z_pred = accelerator.gather(z_pred)
            all_z = accelerator.gather(z)
            
            all_y_score = nn.functional.softmax(all_y_pred, dim=1).cpu().numpy()[:,1].tolist()
            all_y_pred = torch.argmax(all_y_pred, dim=1).detach().cpu().numpy().tolist()

            all_z_score = nn.functional.softmax(all_z_pred, dim=1).cpu().numpy()[:,1].tolist()
            all_z_pred = torch.argmax(all_z_pred, dim=1).detach().cpu().numpy().tolist()
            
            val_score.extend(all_y_score)
            val_pred.extend(all_y_pred)
            
            val_score2.extend(all_z_score)
            val_pred2.extend(all_z_pred)
#             all_y = torch.argmax(all_y, dim=1).detach().cpu().numpy().tolist()
            all_y = all_y.detach().cpu().numpy().tolist()
            all_z = all_z.detach().cpu().numpy().tolist()
            val_true.extend(all_y)
            val_true2.extend(all_z)
            
            if len_stats: len_.extend([int(leng) for leng in length])
                
    if len_stats:
        val_score = np.array(val_score)
        val_pred = np.array(val_pred)
        val_true = np.array(val_true)
        len_ = np.array(len_)
        # positive is white, zero is black
        tp = len_[(val_true==val_pred) & (val_true==1)] # actual=white
        tn = len_[(val_true==val_pred) & (val_true==0)] # actual=black
        fp = len_[(val_true!=val_pred) & (val_true==0)] # pred=white, actual=black
        fn = len_[(val_true!=val_pred) & (val_true==1)] # pred=black, actual=white
        print(f"tp len {len(tp)}")
        print(f"tn len {len(tn)}")
        print(f"fp len {len(fp)}")
        print(f"fn len {len(fn)}")
        draw(min(tp), max(tp), list(tp), title=f"tp", fig_name=f"tp")
        draw(min(tn), max(tn), list(tn), title=f"tn", fig_name=f"tn")
        draw(min(fp), max(fp), list(fp), title=f"fp", fig_name=f"fp")
        draw(min(fn), max(fn), list(fn), title=f"fn", fig_name=f"fn")
        with open("tp", "w+") as file:
            file.write(" ".join(list(map(str, tp))))
        with open("tn", "w+") as file:
            file.write(" ".join(list(map(str, tn))))
        with open("fp", "w+") as file:
            file.write(" ".join(list(map(str, fp))))
        with open("fn", "w+") as file:
            file.write(" ".join(list(map(str, fn))))
    model.train()
    return val_true, val_pred, val_score, val_true2, val_pred2, val_score2

def find_acc(model, datas, device, dataloader, batch_size=32, num_workers=2, len_stats=False, evaluate=False):
    model.eval()
    if evaluate: datas.eval()
    val_true, val_pred, val_score = [], [], []
    len_ = []
    with torch.no_grad():
        for idx, (ids, att, y, z, length) in (enumerate(tqdm(dataloader))):
            y_pred, z_pred = model.forward_eval((ids.to(device), att.to(device)))
            
            y = y.to(device)
            all_y_pred = accelerator.gather(y_pred)
            all_y = accelerator.gather(y)
            
            all_y_score = nn.functional.softmax(all_y_pred, dim=1).cpu().numpy()[:,1].tolist()
            all_y_pred = torch.argmax(all_y_pred, dim=1).detach().cpu().numpy().tolist()
            
            val_score.extend(all_y_score)
            val_pred.extend(all_y_pred)
            
#             all_y = torch.argmax(all_y, dim=1).detach().cpu().numpy().tolist()
            all_y = all_y.detach().cpu().numpy().tolist()
            val_true.extend(all_y)
            
            if len_stats: len_.extend([int(leng) for leng in length])
                
    return val_true, val_pred, val_score

def save_roc(val_pred, val_true):
    fpr, tpr, _ = roc_curve(val_true, val_score)
    roc_auc = auc(fpr, tpr)
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange',
             lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Safety')
    plt.legend(loc="lower right")
    plt.savefig("roc.png")
        
        
