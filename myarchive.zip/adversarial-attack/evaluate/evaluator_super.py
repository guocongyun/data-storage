import os
import time
import json
import numpy as np
import random
import argparse
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader
from transformers import AdamW, \
    get_cosine_schedule_with_warmup, \
    get_linear_schedule_with_warmup, \
    get_polynomial_decay_schedule_with_warmup
from torch import nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, recall_score, precision_score, classification_report, roc_curve, auc, f1_score, recall_score, precision_score, balanced_accuracy_score
import matplotlib.pyplot as plt
from datasets_eval import SafetyDataset
from models import SafetyModel
from data_compression import draw
from tqdm import tqdm
import wandb
from accelerate import Accelerator, DistributedDataParallelKwargs
import glob 

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
os.environ['PYTHONWARNINGS'] = 'ignore:semaphore_tracker:UserWarning'
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# nohup python3 -m torch.distributed.launch --nproc_per_node=4 --nnodes=1 trainer.py >weights/20210627_1_test/logs.out 2>&1 &

# sudo python3 -m torch.distributed.launch --nproc_per_node=8 --master_port 29522 evaluator_super.py --local_rank -1 

parser = argparse.ArgumentParser()
parser.add_argument("--local_rank", type=int, default=-1)
parser.add_argument("--save_path", type=str, default=None)
parser.add_argument("--mode", type=str, default="train")
args = parser.parse_args()


ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
accelerator = Accelerator(fp16=True, kwargs_handlers=[ddp_kwargs])
device = accelerator.device
try:
    args.local_rank = dist.get_rank()
    word_size = dist.get_world_size()
    print("args.local_rank", args.local_rank)
except:
    print("no dist used")
    word_size = 1


def set_seed(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
                
seed = 42
set_seed(seed)

import pdb

def evaluate(model, datas, device, dataloader, batch_size=32, num_workers=2, len_stats=False, evaluate=False):
    model.eval()
    if evaluate: datas.eval()
    val_true, val_pred, val_score = [], [], []
    len_ = []
    with torch.no_grad():
        for idx, (ids, att, y, length) in (enumerate(tqdm(dataloader))):
            y_pred = model((ids.to(device), att.to(device)))
            
            y = y.to(device)
            all_y_pred = accelerator.gather(y_pred.logits)
            all_y = accelerator.gather(y)
            
            all_y_score = nn.functional.softmax(all_y_pred, dim=1).cpu().numpy()[:,1].tolist()
            all_y_pred = torch.argmax(all_y_pred, dim=1).detach().cpu().numpy().tolist()
            val_score.extend(all_y_score)
            val_pred.extend(all_y_pred)
            all_y = torch.argmax(all_y, dim=1).detach().cpu().numpy().tolist()
            val_true.extend(all_y)
            if len_stats: len_.extend([int(leng) for leng in length])
                
    if len_stats:
        val_score = np.array(val_score)
        val_pred = np.array(val_pred)
        val_true = np.array(val_true)
        len_ = np.array(len_)
        # positive is white, zero is black
        tp = len_[(val_true==val_pred) & (val_true==1)] # actual=white
        tn = len_[(val_true==val_pred) & (val_true==0)] # actual=black
        fp = len_[(val_true!=val_pred) & (val_true==0)] # pred=white, actual=black
        fn = len_[(val_true!=val_pred) & (val_true==1)] # pred=black, actual=white
        print(f"tp len {len(tp)}")
        print(f"tn len {len(tn)}")
        print(f"fp len {len(fp)}")
        print(f"fn len {len(fn)}")
        draw(min(tp), max(tp), list(tp), title=f"tp", fig_name=f"tp")
        draw(min(tn), max(tn), list(tn), title=f"tn", fig_name=f"tn")
        draw(min(fp), max(fp), list(fp), title=f"fp", fig_name=f"fp")
        draw(min(fn), max(fn), list(fn), title=f"fn", fig_name=f"fn")
        with open("tp", "w+") as file:
            file.write(" ".join(list(map(str, tp))))
        with open("tn", "w+") as file:
            file.write(" ".join(list(map(str, tn))))
        with open("fp", "w+") as file:
            file.write(" ".join(list(map(str, fp))))
        with open("fn", "w+") as file:
            file.write(" ".join(list(map(str, fn))))
    if evaluate: datas.phrase="train"
    model.train()
    return val_true, val_pred, val_score

def save_roc(val_pred, val_true):
    fpr, tpr, _ = roc_curve(val_true, val_score)
    roc_auc = auc(fpr, tpr)
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange',
             lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Safety')
    plt.legend(loc="lower right")
    plt.savefig("roc.png")

def safety_trainer(epochs=20,
                   batch_size=32,
#                    reformer_model_path="../../pretrains/output_dir_20210728/checkpoint-63987",
                   reformer_model_path="../../pretrains/model_20210726_tok_20210709_checkpoint-99825",
#                    reformer_model_path=None,
                   reformer_tokenizer_path="../../tokenizers/tokenizer_20210709",
                   black_data_path="../../zippos/head_zippo_20210812_tok0810/black_train",
                   white_data_path="../../zippos/head_zippo_20210812_tok0810/white_train",
                   test_black_data_path="../../zippos/head_zippo_20210812_tok0810/black_test",
                   test_white_data_path="../../zippos/head_zippo_20210812_tok0810/white_test",
#                    black_data_path="../../zippos/head_zippo/black_train",
#                    white_data_path="../../zippos/head_zippo/white_train",
#                    test_black_data_path="../../zippos/head_zippo/black_test",
#                    test_white_data_path="../../zippos/head_zippo/white_test",
#                    black_data_path="../../zippos/head_zippo_20210823_tok0810_v2black_train",
#                    white_data_path="../../zippos/head_zippo_20210823_tok0810_v2white_train",
#                    test_black_data_path="../../zippos/head_zippo_20210823_tok0810_v2black_test",
#                    test_white_data_path="../../zippos/head_zippo_20210823_tok0810_v2white_test",
                   save_path="./check_points_with_full_data",
#                    pre_trained_model="./new_full/default, data=0810all, pretrain=0810all-cp63987, init=1, test_size=0.0001 tweaked label_42_loss_0.36769306.pth",
                   pre_trained_model="./new_full/default, data=0709all, init=1, test_size=0.0001 复现_33_loss_0.01093515.pth",
                   start_epoch=0,
                   num_workers=2,
                   num_labels=2,
                   flag_get_idx=False,
                   hidden_dropout_prob=0.5,
                   hidden_size=768,
                   print_parm=1,
                   white_ratio=0.02,
                   maxlen=512,
                   num_hidden_layers=2,
                   len_stats=False,
                   lr=5e-5,
                   weight_decay=1e-3,
                   position_embedding_type="potato",
                   hidden_act="gelu",
                   file_name="Unamed",
                   init_sample=0.1,
                   sample_epoch=0.8,
                   degree=2,
                   overwrite_config=False):


    trainer_config = {"epochs": epochs,
                      "batch_size": batch_size,
                      "reformer_model_path": reformer_model_path,
                      "reformer_tokenizer_path": reformer_tokenizer_path,
                      "black_data_path": black_data_path,
                      "white_data_path": white_data_path,
                      "save_path": save_path,
                      "pre_trained_model": pre_trained_model,
                      "start_epoch": start_epoch,
                      "num_workers": num_workers,
                      "num_labels": num_labels,
                      "flag_get_idx": flag_get_idx,
                      "hidden_dropout_prob": hidden_dropout_prob,
                      "hidden_size": hidden_size,
                      "print_parm": print_parm,
                      "white_ratio": white_ratio,
                      "maxlen": maxlen,
                      "lr": lr,
                      "weight_decay": weight_decay,
                      "test_black_data_path": test_black_data_path,
                      "test_white_data_path": test_white_data_path,
                      "name": "trainer.py",
                      "location": str(os.uname())
                      }
    
    model_config = {"reformer_model_path": reformer_model_path,
                    "reformer_tokenizer_path": reformer_tokenizer_path,
                    "maxlen": maxlen,
                    "vocab_size": 10000,
                    "max_position_embeddings": maxlen+2,
                    "num_attention_heads": 12,
                    "num_hidden_layers": num_hidden_layers,
                    "type_vocab_size": 1,
                    "hidden_dropout_prob": hidden_dropout_prob,
                    "hidden_size": hidden_size,
                    "num_labels": num_labels,
                    "position_embedding_type": position_embedding_type,
                    "hidden_act": hidden_act,
                    "overwrite_config": overwrite_config,
                    }

    if not os.path.exists(save_path):
        try:
            os.mkdir(save_path)
        except:
            pass
    
    model = SafetyModel(**model_config)
    model.load_weights(pre_trained_model)

    dataset_config = {
        "black_data_path": black_data_path,
        "white_data_path": white_data_path,
        "tokenizer": model.tokenizer,
        "maxlen": maxlen,
        "phase": "train",
        "flag_get_idx": flag_get_idx,
        "white_ratio": white_ratio,
        "len_stats": len_stats,
        "init_sample": init_sample,
        "shrink_factor": 1,
    }

#     train_data = SafetyDataset(**dataset_config)
#     train_dataloader = DataLoader(train_data, batch_size=batch_size,
#                                   shuffle=True, num_workers=num_workers)
    
    test_dataset_config = dataset_config.copy()
    test_dataset_config["black_data_path"] = test_black_data_path
    test_dataset_config["white_data_path"] = test_white_data_path
    test_dataset_config["shrink_factor"] = 10
    test_dataset_config["phase"] = "eval"
    test_data = SafetyDataset(**test_dataset_config)
    test_dataloader = DataLoader(test_data, batch_size=batch_size,
                              shuffle=True, num_workers=num_workers)
    
    test_dataset_config2 = dataset_config.copy()
    test_dataset_config2["black_data_path"] = "../../zippos/head_zippo_tweak_label_supertest/black_test" # 2->0709
    test_dataset_config2["white_data_path"] = None
    test_dataset_config2["phase"] = "eval"
    test_data2 = SafetyDataset(**test_dataset_config2)
    test_dataloader2 = DataLoader(test_data2, batch_size=batch_size,
                              shuffle=True, num_workers=num_workers)
    
    dataset_config["tokenizer"] = reformer_tokenizer_path

    config_dict = {
        "trainer_config": trainer_config,
        "model_config": model_config,
        "dataset_config": dataset_config,
    }
    
#     if args.local_rank == 0: 
#         run=wandb.init(name=file_name, entity="asdf1473", project="safety", config=config_dict)
#         print(os.path.join(save_path, "config.json"))
#         with open(os.path.join(save_path, "config.json"), "w+") as f:
#             json.dump(config_dict, f, indent=4)
            
    dataset_config["smiles_tokenizer"] = model.tokenizer

    optimizer = AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    model, optimizer, test_dataloader, test_dataloader2 = accelerator.prepare(
        model, optimizer, test_dataloader, test_dataloader2)
    
#     scheduler = get_polynomial_decay_schedule_with_warmup(optimizer, num_warmup_steps=len(train_dataloader),
#                                                           num_training_steps=(epochs-start_epoch)*len(train_dataloader)/2/init_sample)
#     val_true1, val_pred1, val_score1 = evaluate(model=accelerator.unwrap_model(model), datas=train_data, dataloader=train_dataloader,  device=device, evaluate=True)
    val_true2, val_pred2, val_score2 = evaluate(model=accelerator.unwrap_model(model), datas=test_data2, dataloader=test_dataloader2,  device=device, evaluate=True) # Use only     
    val_true1, val_pred1, val_score1 = evaluate(model=accelerator.unwrap_model(model), datas=test_data, dataloader=test_dataloader,  device=device, evaluate=True) # Use only     
#     model.save_pretrained(accelerator.unwrap_model(model).state_dict(),
#                        "this.pth")
    if args.local_rank == 0:
#         print(roc_auc_score(val_true1, val_pred1))
        print(accuracy_score(val_true1, val_pred1))
        print(classification_report(val_true1, val_pred1))
        
#         print(roc_auc_score(val_true2, val_pred2))
        print(accuracy_score(val_true2, val_pred2))
        print(classification_report(val_true2, val_pred2))
        
#         with open(f"./stats/{pre_trained_model}y_score1", "w+") as f:
#             f.write("\n".join(list(map(str, val_score1))))
#         with open(f"./stats/{pre_trained_model}y_true1", "w+") as f:
#             f.write("\n".join(list(map(str, val_true1))))
#         with open(f"./stats/{pre_trained_model}y_pred1", "w+") as f:
#             f.write("\n".join(list(map(str, val_pred1))))
        
        with open(f"./stats/{str(accuracy_score(val_true2, val_pred2))}y_score2", "w+") as f:
            f.write("\n".join(list(map(str, val_score2))))
        with open(f"./stats/{str(accuracy_score(val_true2, val_pred2))}y_true2", "w+") as f:
            f.write("\n".join(list(map(str, val_true2))))
        with open(f"./stats/{str(accuracy_score(val_true2, val_pred2))}y_pred2", "w+") as f:
            f.write("\n".join(list(map(str, val_pred2))))

    dist.barrier()

if __name__ == "__main__":
    if args.mode == "train":  
        paths = ["./new_full/default, data=0810all, pretrain=0810all-cp63987, init=1, test_size=0.0001 tweaked label_42_loss_0.36769306.pth","./new_full/default, data=0709all, init=1, test_size=0.0001 复现_33_loss_0.01093515.pth","./new_full/default, data=0810all, pretrain=0810all-cp63987, init=1, test_size=0.0001_38_loss_0.01180692.pth"]
        safety_trainer(epochs=50, batch_size=32, maxlen=512, hidden_dropout_prob=0.5, init_sample=1, file_name=f"default, data=all, , init=1, evaluation")
#         safety_trainer(epochs=50, batch_size=32, maxlen=515, hidden_dropout_prob=0.5, hidden_size=768, num_hidden_layers=3, init_sample=1, file_name=f"default, data=all, , init=1, evaluation")

        
    else:
        model_test()

        
        
