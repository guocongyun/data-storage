from torch.utils.data import Dataset
import json
import numpy as np
import torch
import random
from sklearn.model_selection import train_test_split

import os
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.processors import RobertaProcessing
from datasets import load_dataset, load_from_disk, concatenate_datasets

class SafetyDataset(Dataset):
    def __init__(self,
                 black_data_path,
                 white_data_path,
                 tokenizer,
                 test_data_path=None,
                 maxlen=512,
                 phase="train",
                 flag_get_idx=False,
                 white_ratio=1,
                 test_size=0.2,
                 len_stats=False,
                 model_type="nlp",
                 init_sample=0.1,
                 label = 0,
#                  full_sample_epoch=0.2,
#                  t_epoch=10,
#                  c_epoch=0,
                ):
        super(SafetyDataset, self).__init__()     
        self.competence=self.init_sample=init_sample
        self.len_stats=len_stats
        self.maxlen = maxlen
        self.tokenizer = tokenizer
        self.phase = phase
        self.black_data_path = black_data_path
        self.white_data_path = white_data_path
        self.flag_get_idx = flag_get_idx
        self.model_type = model_type
        self.string_list = []
        
        if self.len_stats:
            self.tokenizer2 = Tokenizer(BPE(os.path.join("../tokenizer","vocab.json"),
                os.path.join("../tokenizer","merges.txt")))
        id2chi_dict = {1: '㤥', 2: '㤦', 3: '㤧', 4: '㤨', 5: '㤩', 6: '㤪', 7: '㤫', 8: '㤬', 9: '㤭', 10: '㤮', 11: '㤯', 12: '㤰', 13: '㤱', 14: '㤲', 15: '㤳', 16: '㤴', 17: '㤵', 18: '㤶', 19: '㤷', 20: '㤸', 21: '㤹', 22: '㤺', 23: '㤻', 24: '㤼', 25: '㤽', 26: '㤾', 27: '㤿', 28: '㥀', 29: '㥁', 30: '㥂', 31: '㥃', 32: '㥄', 33: '㥅', 34: '㥆', 35: '㥇', 36: '㥈', 37: '㥉', 38: '㥊', 39: '㥋', 40: '㥌', 41: '㥍', 42: '㥎', 43: '㥏', 44: '㥐', 45: '㥑', 46: '㥒', 47: '㥓', 48: '㥔', 49: '㥕', 50: '㥖', 51: '㥗', 52: '㥘', 53: '㥙', 54: '㥚', 55: '㥛', 56: '㥜', 57: '㥝', 58: '㥞', 59: '㥟', 60: '㥠', 61: '㥡', 62: '㥢', 63: '㥣', 64: '㥤', 65: '㥥', 66: '㥦', 67: '㥧', 68: '㥨', 69: '㥩', 70: '㥪', 71: '㥫', 72: '㥬', 73: '㥭', 74: '㥮', 75: '㥯', 76: '㥰', 77: '㥱', 78: '㥲', 79: '㥳', 80: '㥴', 81: '㥵', 82: '㥶', 83: '㥷', 84: '㥸', 85: '㥹', 86: '㥺', 87: '㥻', 88: '㥼', 89: '㥽', 90: '㥾', 91: '㥿', 92: '㦀', 93: '㦁', 94: '㦂', 95: '㦃', 96: '㦄', 97: '㦅', 98: '㧪', 99: '㦇', 100: '㦈', 101: '㦉', 102: '㦊', 103: '㦋', 104: '㦌', 105: '㦍', 106: '㦎', 107: '㦏', 108: '㦐', 109: '㦑', 110: '㦒', 111: '㦓', 112: '㦔', 113: '㦕', 114: '㦖', 115: '㦗', 116: '㦘', 117: '㦙', 118: '㦚', 119: '㦛', 120: '㦜', 121: '㦝', 122: '㦞', 123: '㦟', 124: '㦠', 125: '㦡', 126: '㦢', 127: '㦣', 128: '㦤', 129: '㦥', 130: '㦦', 131: '㦧', 132: '㦨', 133: '㦩', 134: '㦪', 135: '㦫', 136: '㦬', 137: '㦭', 138: '㦮', 139: '㦯', 140: '㦰', 141: '㦱', 142: '㦲', 143: '㦳', 144: '㦴', 145: '㦵', 146: '㦶', 147: '㦷', 148: '㦸', 149: '㦹', 150: '㦺', 151: '㦻', 152: '㦼', 153: '㦽', 154: '㦾', 155: '㦿', 156: '㧀', 157: '㧁', 158: '㧂', 159: '㧃', 160: '㧄', 161: '㧅', 162: '㧆', 163: '㧇', 164: '㧈', 165: '㧉', 166: '㧊', 167: '㧋', 168: '㧌', 169: '㧍', 170: '㧎', 171: '㧏', 172: '㧐', 173: '㧑', 174: '㧒', 175: '㧓', 176: '㧔', 177: '㧕', 178: '㧖', 179: '㧗', 180: '㧘', 181: '㧙', 182: '㧚', 183: '㧛', 184: '㧜', 185: '㧝', 186: '㧞', 187: '㧟', 188: '㧠', 189: '㧡', 190: '㧢', 191: '㧣', 192: '㧤', 193: '㧥', 194: '㧦', 195: '㧧', 196: '㧨', 197: '㧩', 198: '㧪', 199: '㧫', 200: '㧬', 201: '㧭', 202: '㧮', 203: '㧯', 204: '㧰', 205: '㧱', 206: '㧲', 207: '㧳', 208: '㧴', 209: '㧵', 210: '㧶', 211: '㧷', 212: '㧸', 213: '㧹', 214: '㧺', 215: '㧻',
                       216: '㧼', 217: '㧽', 218: '㧾', 219: '㧿', 220: '㨀', 221: '㨁', 222: '㨂', 223: '㨃', 224: '㨄', 225: '㨅', 226: '㨆', 227: '㨇', 228: '㨈', 229: '㨉', 230: '㨊', 231: '㨋', 232: '㨌', 233: '㨍', 234: '㨎', 235: '㨏', 236: '㨐', 237: '㨑', 238: '㨒', 239: '㨓', 240: '㨔', 241: '㨕', 242: '㨖', 243: '㨗', 244: '㨘', 245: '㨙', 246: '㨚', 247: '㨛', 248: '㨜', 249: '㨝', 250: '㨞', 251: '㨟', 252: '㨠', 253: '㨡', 254: '㨢', 255: '㨣', 256: '㨤', 257: '㨥', 258: '㨦', 259: '㨧', 260: '㨨', 261: '㨩', 262: '㨪', 263: '㨫', 264: '㨬', 265: '㨭', 266: '㨮', 267: '㨯', 268: '㨰', 269: '㨱', 270: '㨲', 271: '㨳', 272: '㨴', 273: '㨵', 274: '㨶', 275: '㨷', 276: '㨸', 277: '㨹', 278: '㨺', 279: '㨻', 280: '㨼', 281: '㨽', 282: '㨾', 283: '㨿', 284: '㩀', 285: '㩁', 286: '㩂', 287: '㩃', 288: '㩄', 289: '㩅', 290: '㩆', 291: '㩇', 292: '㩈', 293: '㩉', 294: '㩊', 295: '㩋', 296: '㩌', 297: '㩍', 298: '㩎', 299: '㩏', 300: '㩐', 301: '㩑', 302: '㩒', 303: '㩓', 304: '㩔', 305: '㩕', 306: '㩖', 307: '㩗', 308: '㩘', 309: '㩙', 310: '㩚', 311: '㩛', 312: '㩜', 313: '㩸', 314: '㩞', 315: '㩟', 316: '㩠', 317: '㩡', 318: '㩢', 319: '㩣', 320: '㩤', 321: '㩥', 322: '㩦', 323: '㩧', 324: '㩨', 325: '㩩', 326: '㩪', 327: '㩫', 328: '㩬', 329: '㩭', 330: '㩮', 331: '㩯', 332: '㩰', 333: '㩱', 334: '㩲', 335: '㩳', 336: '㩴', 337: '㩵', 338: '㩶', 339: '㩷', 340: '㩸', 341: '㩹', 342: '㩺', 343: '㩻', 344: '㩼', 345: '㩽', 346: '㩾', 347: '㩿', 348: '㪀', 349: '㪁', 350: '㪂', 351: '㪃', 352: '㪄', 353: '㪅', 354: '㪆', 355: '㪇', 356: '㪈', 357: '㪉', 358: '㪊', 359: '㪋', 360: '㪌', 361: '㪍', 362: '㪎', 363: '㪏', 364: '㪐', 365: '㪑', 366: '㪒', 367: '㪓', 368: '㪔', 369: '㪕', 370: '㪖', 371: '㪗', 372: '㪘', 373: '㪙', 374: '㪚', 375: '㪛', 376: '㪜', 377: '㪝', 378: '㪞', 379: '㪟', 380: '㪠', 381: '㪡', 382: '㪢', 383: '㪣', 384: '㪤', 385: '㪥', 386: '㪦', 387: '㪧', 388: '㪨', 389: '㪩', 390: '㪪', 391: '㪫', 392: '㪬', 393: '㪭', 394: '㪮', 395: '㪯', 396: '㪰', 397: '㪱', 398: '㪲', 399: '㪳', 400: '㪴', 401: '㪵', 402: '㪶', 403: '㪷', 404: '㪸', 405: '㪹', 406: '㪺', 407: '㪻', 408: '㪼', 409: '㪽', 410: '㪾', 411: '㪿', 412: '㫀', 413: '㫁', 414: '㫂', 415: '㫃', 416: '㫄', 417: '㫅', 418: '㫆', 419: '㫇', 420: '㫈'}
        self.chi2id_dict = {v: k-1 for k, v in id2chi_dict.items()}
        self.epoch = 0
        black, white = None, None
        if self.black_data_path is not None:
            black = load_from_disk(self.black_data_path)
        if self.white_data_path is not None:
            white = load_from_disk(self.white_data_path)
        
        if black and white: 
            self.black = black.train_test_split(test_size=test_size, shuffle=True)
            self.black["train"] = self.black["train"].sort("confidence", reverse=True)
            self.white = white.train_test_split(test_size=test_size, shuffle=True)
            self.white["train"] = self.white["train"].sort("confidence", reverse=True)
        else:
            self.black = black
            self.black = self.black.train_test_split(test_size=test_size, shuffle=False)
            self.white = None
#         self.data = concatenate_datasets([black, white])
#         self.data = self.data.train_test_split(test_size=test_size)
        
#         self.data["train"] = self.data["train"].sort("confidence", reverse=True)
#         for i in range(100):
#             print(self.data["train"][i]["label"])
#             print(self.data["train"][i]["confidence"])            
#         exit()
        if self.white: print(len(self.black["train"])+len(self.black["test"])+len(self.white["train"])+len(self.white["test"]))
        else: print(len(self.black["train"])+len(self.black["test"]))
#             self.train = sorted(self.train, key=lambda x: len(x["data"]))                

#     def get_ids_n_mask(self, safety_string):
#         encode_dict = self.tokenizer.encode(sequence=safety_string["data"])
#         safety_ids = np.array(encode_dict.ids)
#         safety_mask = np.array(encode_dict.attention_mask)
#         label = safety_string["label"]
# #         if self.len_stats:
# #             encode_dict2 = self.tokenizer2.encode(sequence=safety_string)
# #             safety_ids2 = np.array(encode_dict2.ids)
# #             return safety_ids, safety_mask, label, len(safety_ids2)
#         return safety_ids, safety_mask, label, 0

    def __len__(self):
        if self.phase == "train":
            return int(int(len(self.black["train"])*self.competence)+int(len(self.white["train"])*self.competence))
        elif self.phase == "eval":
            if self.white: return int(len(self.black["test"]))+int(len(self.white["test"]))
            else: return int(len(self.black["test"]))

    def getitem_nlp(self, index):
        if self.phase == "train":
            if index >= int(len(self.black["train"])*self.competence):
                ds = self.white["train"]
                index -= int(len(self.black["train"])*self.competence)
            elif index < int(len(self.black["train"])*self.competence):
                ds = self.black["train"]
        elif self.phase == "eval":
            if index >= int(len(self.black["test"])):
                ds = self.white["test"]
                index -= int(len(self.black["test"]))
            elif index < int(len(self.black["test"])):
                ds = self.black["test"]
                
        safety_ids, safety_mask, label, leng = ds[index]["input_ids"], ds[index]["attention_mask"], ds[index]["label"], ds[index]["length"]
#         self.get_ids_n_mask(new_safety_string)
        label = 0.95 if label == 1 else 0.15
        label = [1-label, label]
        if self.flag_get_idx:
            return (torch.tensor(index),
                    torch.tensor(safety_ids),
                    torch.tensor(safety_mask),
                    torch.tensor(label),
                    )

        return (torch.tensor(safety_ids),
                torch.tensor(safety_mask),
                torch.tensor(label),
                leng)

    def update_competence(self, c_epoch=0, t_epoch=10, sample_epoch=0.8, degree=2):
        t = c_epoch
        T = t_epoch*sample_epoch
        c = self.init_sample
        self.competence = min(1, np.sqrt(t*(1-c**degree)/T+c**degree))
    
#     def get_competence(self, c_epoch=0, t_epoch=10, sample_epoch=0.8):
#         t = c_epoch
#         T = t_epoch*sample_epoch
#         c = self.init_sample
#         return min(1, np.sqrt(t*(1-c**2)/T+c**2))
    
#     def update_competence(self, c_epoch=0, t_epoch=10, sample_epoch=0.8):
#         self.competence = self.get_competence(c_epoch=c_epoch, t_epoch=t_epoch, sample_epoch=sample_epoch)
    
#     def get_total_step(self,c_epoch=0, t_epoch=10, sample_epoch=0.8):
#         sum_competence = 0
#         for i in range(t_epoch):
#             sum_competence += self.get_competence(c_epoch=i, t_epoch=t_epoch, sample_epoch=sample_epoch)
#         return int(sum_competence*len(self.train))
    
    def str2mlptensor(self, new_safety_string):
        item = torch.zeros(420)
        for i in new_safety_string:
            item[self.chi2id_dict[i]] += 1
        item = item / len(new_safety_string)
        return item
    
    def getitem_mlp(self, index):
        if self.phase == "train":
            new_safety_string = self.train_data[index]
            label = torch.tensor(self.train_labels[index])
        elif self.phase == "eval":
            new_safety_string = self.val_data[index]
            label = torch.tensor(self.val_labels[index])
        else:
            new_safety_string = self.string_list[index]
            if index <= len(self.label):
                label = torch.tensor(self.label[index])
            else:
                label = None

        if self.flag_get_idx:
            return (torch.tensor(index),
                    new_safety_string,
                    label
                    )

        return (new_safety_string, label)

    def __getitem__(self, index):
        if self.model_type == "nlp":
            return self.getitem_nlp(index)
        elif self.model_type == "mlp":
            return self.getitem_mlp(index)

    def change_data(self, epoch):
        pass

    def train(self):
        self.phase = 'train'

    def eval(self):
        self.phase = 'eval'

    def test(self):
        self.phase = 'test'
