import os
import time
import json
import numpy as np
import random
import argparse
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader
from transformers import AdamW, \
    get_cosine_schedule_with_warmup, \
    get_linear_schedule_with_warmup, \
    get_polynomial_decay_schedule_with_warmup
from torch import nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, recall_score, precision_score, classification_report, roc_curve, auc, f1_score, recall_score, precision_score, balanced_accuracy_score
import matplotlib.pyplot as plt
from dataset.datasetss import Dataset
from model.models import Model
from preprocess.data_compression import draw
from tqdm import tqdm
import wandb
from accelerate import Accelerator, DistributedDataParallelKwargs
from transformers.trainer_utils import get_last_checkpoint
from loss_function.fgm import FGM
from utils.set_seed import set_seed
from evaluate.evaluator import evaluate
from tokenizer.bpe import MyTokenizer
# sudo python3 -m torch.distributed.run --nproc_per_node=8 --master_port 29522 trainer.py --local_rank -1 

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['PYTHONWARNINGS'] = 'ignore:semaphore_tracker:UserWarning'
os.environ["TOKENIZERS_PARALLELISM"] = "false"

parser = argparse.ArgumentParser()
parser.add_argument("--local_rank", type=int, default=-1)
parser.add_argument("--save_path", type=str, default=None)
parser.add_argument("--mode", type=str, default="train")
args = parser.parse_args()

ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
accelerator = Accelerator(fp16=True, kwargs_handlers=[ddp_kwargs])
device = accelerator.device
try:
    args.local_rank = dist.get_rank()
    word_size = dist.get_world_size()
    print("args.local_rank", args.local_rank)
except:
    print("no dist used")
    word_size = 1
            
set_seed(42)

# torch.rand(1, 2).to('cuda:0') # cuda out of memory error
# print(device)
# print(torch.rand(1, 2).to('cuda:1')) # cuda out of memory error


# exit()

def trainer(
        model,
        tokenizer,
        train_data,
        eval_data,
        test_data,
        online_data,
        config_dict,
        pretrain_torch_model=None,
        start_epoch=0,
        total_epochs=500,
        batch_size=32,
        cumulative_batch_size=128,
        save_path="./save",
        num_workers=4,
        print_parm=1,
        lr=5e-5,
        weight_decay=1e-3,
        use_rdrop=False,
        use_rdrop_alpha=1,
        use_fgm=False,
        run_name="Test",
        overwrite_config=False,
        wandb_idx=None,
        shuffle=True,
        cirr_init_sample=1,
        cirr_training_ratio=0,
        cirr_degree=1,
):

    
    if not os.path.exists(save_path):
        try: os.mkdir(save_path)
        except: pass
    model.load_weights(pretrain_torch_model)
    
    train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    eval_dataloader = DataLoader(eval_data, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    test_dataloader = DataLoader(test_data, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    online_dataloader = DataLoader(online_data, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    
    if cirr_init_sample != 1: total_step = total_epochs*len(train_dataloader)/2/cirr_init_sample
    else: total_step = total_epochs*len(train_dataloader)
    
    optimizer = AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = get_polynomial_decay_schedule_with_warmup(optimizer, num_warmup_steps=len(train_dataloader), num_training_steps=total_step)
    
    if pretrain_torch_model:
        check_point_path = pretrain_torch_model.replace(".pth", ".checkpoint")
        if pretrain_torch_model is not None and os.path.exists(check_point_path):
            dict_tmp = torch.load(
                check_point_path, map_location=torch.device('cpu'))
            optimizer.load_state_dict(dict_tmp["optimizer"])
            scheduler.load_state_dict(dict_tmp["scheduler"])
            start_epoch = dict_tmp["epoch"]   
    
    model, optimizer, train_dataloader, test_dataloader, eval_dataloader, online_dataloader = accelerator.prepare(model, optimizer, train_dataloader, test_dataloader, eval_dataloader, online_dataloader)
    
    if args.local_rank == 0: 
        if wandb_idx: run=wandb.init(id=wandb_idx, name=run_name, entity="asdf1473", project="safety", config=config_dict, resume="allow")
        else: run=wandb.init(name=run_name, entity="asdf1473", project="safety", config=config_dict)
    
    for epoch in range(start_epoch, total_epochs):
        train_dataloader.dataset.update_competence(start_epoch, total_epochs, cirr_training_ratio, cirr_degree)
        torch.cuda.empty_cache()
        train_loss_sum = 0.0
        start = time.time()
        optimizer.zero_grad()  
        
        for idx, batch in enumerate(tqdm(train_dataloader)):
            safety_ids_tensor, safety_mask_tensor, labels1, labels2, _ = batch
            safety_tensor = (safety_ids_tensor.to(device), safety_mask_tensor.to(device))
            total_loss = model(safety_tensor, labels1.to(device), labels2.to(device), device=device)
            accelerator.backward(total_loss)
            
            if (idx+1) % int(cumulative_batch_size/batch_size) == 0:
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                
            train_loss_sum += total_loss.item()
            if args.local_rank % 4 == 0 and (idx + 1) % (len(train_dataloader)//5+1) == 0:
                print("Epoch {:04d} | Step {:04d}/{:04d} | Loss {:.4f} | Time {:.4f}".format(
                    epoch+1, idx+1, len(train_dataloader),
                    train_loss_sum/(idx+1),
                    time.time() - start))
                print("Learning rate = {}".format(
                    optimizer.state_dict()['param_groups'][0]['lr']))
        if args.local_rank == 0 and epoch % print_parm == 0:
            name = run_name+"_{}_loss_{}.pth".format(epoch, round(train_loss_sum/len(train_dataloader), 8))
            torch.save(accelerator.unwrap_model(model).state_dict(),
                       os.path.join(save_path, name))
            checkpoint_dict = {
                "epoch": epoch,
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
            }
            torch.save(checkpoint_dict, os.path.join(save_path, name.replace(".pth", ".checkpoint")))
            
        val_true1, val_pred1, val_score1 = evaluate(model=accelerator.unwrap_model(model), datas=test_data2, dataloader=eval_dataloader,  device=device, evaluate=True)
        val_true2, val_pred2, val_score2 = evaluate(model=accelerator.unwrap_model(model), datas=test_data, dataloader=test_dataloader,  device=device, evaluate=True)
        val_true3, val_pred3, val_score3 = evaluate(model=accelerator.unwrap_model(model), datas=train_data2, dataloader=online_dataloader,  device=device, evaluate=True)
        
        if args.local_rank == 0:
            print(classification_report(val_true2, val_pred2))
            wandb.log({
               "epoch": epoch, 
               "loss": train_loss_sum/len(train_dataloader),
               "acc_train":accuracy_score(val_true3, val_pred3),
               "balanced_acc_train":balanced_accuracy_score(val_true3, val_pred3),
               "acc_test":accuracy_score(val_true2, val_pred2),
               "balanced_acc_test":balanced_accuracy_score(val_true2, val_pred2),
               "acc_online":accuracy_score(val_true1, val_pred1),
               "balanced_acc_online":balanced_accuracy_score(val_true1, val_pred1),
            })
        dist.barrier()
    if args.local_rank == 0: run.finish()        


def main(config_path="./config/roberta.json"):
    with open(config_path, "r") as f:
        config_dict = json.loads(f.read())
    
    train_config = config_dict["trainer_config"]
    model_config = config_dict["model_config"]
    dataset_config = config_dict["dataset_config"]
    tokenizer_config = config_dict["tokenizer_config"]
    
    model = Model(**model_config)
    tokenizer = MyTokenizer(**tokenizer_config)
    
    dataset_config["tokenizer"] = tokenizer
    dataset_config["max_position_embeddings"] = model_config["max_position_embeddings"]
    
    train_dataset_config = dataset_config["all"].copy()
    train_dataset_config["black_data_path"] = dataset_config["train"]["black_data_path"]
    train_dataset_config["white_data_path"] = dataset_config["train"]["white_data_path"]
    train_dataset_config["test_size"] = dataset_config["train"]["test_size"]
    train_data = Dataset(**train_dataset_config)
    
    eval_dataset_config = dataset_config["all"].copy()
    eval_dataset_config["black_data_path"] = dataset_config["eval"]["black_data_path"]
    eval_dataset_config["white_data_path"] = dataset_config["eval"]["white_data_path"]
    eval_dataset_config["test_size"] = dataset_config["eval"]["test_size"]
    eval_data = Dataset(**eval_dataset_config)
    
    test_dataset_config = dataset_config["all"].copy()
    test_dataset_config["black_data_path"] = dataset_config["test"]["black_data_path"]
    test_dataset_config["white_data_path"] = dataset_config["test"]["white_data_path"]
    test_dataset_config["test_size"] = dataset_config["test"]["test_size"]
    test_data = Dataset(**test_dataset_config)
    
    online_dataset_config = dataset_config["all"].copy()
    online_dataset_config["black_data_path"] = dataset_config["online"]["black_data_path"]
    online_dataset_config["white_data_path"] = dataset_config["online"]["white_data_path"]
    online_dataset_config["test_size"] = dataset_config["online"]["test_size"]
    online_data = Dataset(**online_dataset_config)
    
    trainer(model = model, 
            tokenizer = tokenizer, 
            train_data = train_data,
            eval_data = eval_data,
            test_data = test_data,
            online_data = online_data,
            config_dict = config_dict,
            **train_config)


if __name__ == "__main__":
    main()

        
        
