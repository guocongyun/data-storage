import os
import json
from tqdm import tqdm
from typing import List
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.processors import RobertaProcessing
import matplotlib.pyplot as plt
from transformers import RobertaTokenizer
import regex as re


class MyRobertaTokenizer(RobertaTokenizer):
    def _tokenize(self, text):
        """ Tokenize a string. """
        bpe_tokens = []
        for token in re.findall(self.pat, text):
            # token = "".join(
            #     self.byte_encoder[b] for b in token
            # )  # Maps all our bytes to unicode strings, avoiding controle tokens of the BPE (spaces in our case)
            bpe_tokens.extend(
                bpe_token for bpe_token in self.bpe(token).split(" "))
        return bpe_tokens


def id_to_name(input_file: str) -> dict:
    # Create dictionary mapping from id to str

    id2name = {}
    with open(input_file, encoding="utf-8") as file:
        for line in file:
            api = json.loads(line)
            id2name[api["I"]] = api["name"]
    return id2name


def name_to_chi(input_file: str, output_file: str = None) -> dict:
    # 13525-13550: category
    # 13000-13500: id
    # TODO use information about category

    name = []
    with open(input_file, "r", encoding="utf-8") as file:
        for line in file:
            api = json.loads(line)
            name.append(api["name"])

    printable_glyphs = [chr(x) for x in range(
        0, 0x10ffff+1) if chr(x).isprintable()]
    name2chi = {}
    for idx, value in enumerate(name):
        name2chi[value] = printable_glyphs[idx+0x3400]
    if output_file is not None:
        with open(output_file, "w") as file:
            json.dump(name2chi, file)
    return name2chi


def id_to_chi(input_file: str, output_file: str = None) -> dict:
    # Create dictionary mapping from id to chi

    id2name = id_to_name(input_file=input_file)
    name2chi = name_to_chi(input_file=input_file, output_file=None)
    id2chi = {}
    for key, value in id2name.items():
        id2chi[key] = name2chi[value]

    if output_file is not None:
        with open(output_file, "w") as file:
            json.dump(id2chi, file)
    return id2chi


def data_extraction(input_dir: str, output_txt_path: str, id_mapping: dict, sep_code: str = " ") -> List[int]:
    # Extract key information from given directory
    # total 376064240 248519
    # black 279659207 248519
    # white 96405033 237088
    assert(not os.path.exists(output_txt_path), "exists {output_txt_path}")
    path_list = sorted(os.listdir(input_dir))
    line_counts = []
    for path in tqdm(path_list):
        file_path = os.path.join(input_dir, path)
        data = []
        with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
            for line in file:
                cur_call = json.loads(line)
                if cur_call['type'] == 'call':
                    data.append(id_mapping[cur_call['I']])

        with open(output_txt_path, "a") as file:
            file.write("".join(data))
            file.write(sep_code)
        line_counts.append(len(data))
    return line_counts


def build_token(files,
                save_folder,
                test_code=None):
    tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
    if not isinstance(files, List):
        files = [files]
    # trainer = BpeTrainer(vocab_size=100,
    #                     min_frequency=1000000,
    #                     special_tokens=["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"])
    trainer = BpeTrainer(vocab_size=10000,
                         min_frequency=1000,
                         special_tokens=["<s>", "<pad>", "</s>", "<unk>", "<mask>"])
    tokenizer.pre_tokenizer = Whitespace()

    tokenizer.train(files, trainer)
    if not os.path.exists(save_folder):
        os.mkdir(save_folder)
    tokenizer.model.save(save_folder)
    if test_code is not None:
        encoding = tokenizer.encode(test_code)
        print("Encoded string: {}".format(encoding.tokens))
        print("Encoded ids: {}".format(encoding.ids))
        decoded = tokenizer.decode(encoding.ids)
        print("Decoded string: {}".format(decoded))


def test_txt(txt_path,
             vocab_path,
             merges_path):
    # 376064240 248519
    # 15661188 35503
    # number (>1024): 4472 number (>512): 7778
    tokenizer = MyRobertaTokenizer.from_pretrained(
        "tokenizer2", max_len=512)
    # bpe_model = BPE(vocab_path, merges_path)
    # tokenizer = Tokenizer(bpe_model)
    # tokenizer.enable_padding(pad_id=1, pad_token="<pad>", length=512)
    # tokenizer.enable_truncation(max_length=512)
    # tokenizer.post_processor = RobertaProcessing(
    #     ("</s>", tokenizer.token_to_id("</s>")),
    #     ("<s>", tokenizer.token_to_id("<s>")),)
    if isinstance(txt_path, List):
        context = []
        for i in txt_path:
            with open(i, "r") as f:
                context += [line.strip()
                            for line in f.read().split(" ") if line != ""]
    else:
        with open(txt_path, "r") as f:
            context = [line.strip()
                       for line in f.read().split(" ") if line != ""]
    len_ = []
    num_512 = 0
    num_1024 = 0
    for i in tqdm(context):
        encoding = tokenizer.encode(i)
        print(encoding)
        raise
        # print("Encoded string: {}".format(encoding.tokens))
        # print("Encoded ids: {}".format(encoding.ids))
        # decoded = tokenizer.decode(encoding.ids)
        # print("Decoded string: {}".format(decoded))
        # raise
    #     len_ids = len(encoding.ids)
    #     if len_ids > 1024:
    #         num_1024 += 1
    #         num_512 += 1
    #     elif len_ids > 512:
    #         num_512 += 1
    #     len_.append(len_ids)
    # print("sum_len", sum(len_), "max_len", max(len_))
    # print("number (>1024):", num_1024, "number (>512):", num_512)
    # return len_


def draw(x_min, x_max, data, title, fig_name="default"):
    plt.title(title)
    plt.hist(data, bins=50)
    plt.xlim(x_min, x_max)
    plt.tight_layout()
    plt.savefig(f"{fig_name}.png")
    plt.clf()


def data_convert(input_dir: str, output_txt_path: str, id_mapping: dict, sep_code: str = " ") -> List[int]:
    assert(not os.path.exists(output_txt_path)), "exists {output_txt_path}"
    path_list = sorted(os.listdir(input_dir))
    line_counts = []
    for path in tqdm(path_list):
        file_path = os.path.join(input_dir, path)
        with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
            for line in file:
                datas = [l.strip() for l in line.split(",") if l.strip() != ""]
                with open(output_txt_path, "a", encoding="utf-8") as file:
                    file.write(
                        "".join(list(map(lambda name: id_mapping[name], datas))))
                    file.write(sep_code)
                line_counts.append(len(datas))
    return line_counts


if __name__ == "__main__":
    print("Starting data extraction\n")

    # Create mapping from id number to chinese encoding or api name
    id2chi = id_to_chi(input_file="data/api", output_file="data/id2chi")
    name2chi = name_to_chi(input_file="data/api", output_file="data/name2chi")
    # print(id2chi)
    # Convert
    # sum_len 763168096 max_len 1502201 159180
    line_counts = []
    line_counts = data_convert("data/safety_new_data_20210705/black",
                                "data/safety_new_data_20210705/black_log_processed.txt", name2chi, sep_code=" ")
    print("sum_len", sum(line_counts), "max_len", max(line_counts), len(line_counts))

    line_counts = data_convert("data/safety_new_data_20210705/white",
                                "data/safety_new_data_20210705/white_log_processed.txt", name2chi, sep_code=" ")
    print("sum_len", sum(line_counts), "max_len", max(line_counts), len(line_counts))

    line_counts = data_convert("data/safety_new_data_20210705/test_black",
                                "data/safety_new_data_20210705/test_black_log_processed.txt", name2chi, sep_code=" ")
    print("sum_len", sum(line_counts), "max_len", max(line_counts), len(line_counts))

    line_counts = data_convert("data/safety_new_data_20210705/test_white",
                                "data/safety_new_data_20210705/test_white_log_processed.txt", name2chi, sep_code=" ")
    print("sum_len", sum(line_counts), "max_len", max(line_counts), len(line_counts))
    
    # Extract api name from logs using multiprocess
    # line_counts = []
    # line_counts += data_extraction("data/log_safe/black_log",
    #                                "data/black_log_processed2.txt", id2chi, sep_code="\n")
    # line_counts += data_extraction("data/log_safe/white_log",
    #                                "data/white_log_processed2.txt", id2chi, sep_code="\n")
    # print("sum_len", sum(line_counts), "max_len", max(line_counts))

    # #compression
    # build_token(files=["data/black_log_processed.txt",
    #                    "data/white_log_processed.txt",
    #                    "data/test_data/black_log_processed.txt",
    #                    "data/test_data/white_log_processed.txt"],
    #             save_folder="tokenizer_20210629")

    # test
    # len_ = test_txt(txt_path=["data/test_data/black_log_processed.txt",
    #                           "data/test_data/white_log_processed.txt"],
    #                 vocab_path="tokenizer_20210629/vocab.json",
    #                 merges_path="tokenizer_20210629/merges.txt")
    # draw(min(len_), max(len_), len_, "len_")
    print("Finished")
