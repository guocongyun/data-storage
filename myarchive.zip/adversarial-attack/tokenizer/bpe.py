import os
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.processors import RobertaProcessing
from transformers import RobertaTokenizer

class MyTokenizer:
    
    def __init__(
        self,
        tokenizer_path="./tokenizer",
        pad_id=1,
        pad_token="pad_token",
        truncation=True,
        post_process=True,
        max_position_embeddings=512,
    ):
        print(tokenizer_path)
        self.tokenizer = Tokenizer(BPE(os.path.join(tokenizer_path,"vocab.json"),
                            os.path.join(tokenizer_path,"merges.txt")))
        if pad_id and pad_token and max_position_embeddings:
            self.tokenizer.enable_padding(pad_id=pad_id, pad_token=pad_token, length=max_position_embeddings)
        if truncation and max_position_embeddings:
            self.tokenizer.enable_truncation(max_length=max_position_embeddings)
        if post_process:
            self.tokenizer.post_processor = RobertaProcessing(
                ("</s>", self.tokenizer.token_to_id("</s>")),
                ("<s>", self.tokenizer.token_to_id("<s>")),
            )
            
    def encode(self, sequence):
        return self.tokenizer.encode(sequence=sequence)