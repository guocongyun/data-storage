import os
import torch
from torch import nn
from transformers import RobertaForSequenceClassification, ReformerForSequenceClassification, RobertaModel
from transformers import RobertaConfig, ReformerConfig, AutoConfig, RobertaForQuestionAnswering, RobertaModel
from transformers.models.roberta.modeling_roberta import RobertaEmbeddings
from torch.nn import BCEWithLogitsLoss, CrossEntropyLoss, MSELoss
from typing import Optional
import torch.nn.functional as F
from torch.autograd import Variable
from transformers.modeling_outputs import QuestionAnsweringModelOutput

class FocalLoss(nn.Module):
    def __init__(self, gamma=0, alpha=None, size_average=True):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        if isinstance(alpha,(float,int)): self.alpha = torch.Tensor([alpha,1-alpha])
        if isinstance(alpha,list): self.alpha = torch.Tensor(alpha)
        self.size_average = size_average

    def forward(self, input, target):
        if input.dim()>2:
            input = input.view(input.size(0),input.size(1),-1)  # N,C,H,W => N,C,H*W
            input = input.transpose(1,2)    # N,C,H*W => N,H*W,C
            input = input.contiguous().view(-1,input.size(2))   # N,H*W,C => N*H*W,C
        target = target.view(-1,1)

        logpt = F.log_softmax(input)
        logpt = logpt.gather(1,target)
        logpt = logpt.view(-1)
        pt = Variable(logpt.data.exp())

        if self.alpha is not None:
            if self.alpha.type()!=input.data.type():
                self.alpha = self.alpha.type_as(input.data)
            at = self.alpha.gather(0,target.data.view(-1))
            logpt = logpt * Variable(at)

        loss = -1 * (1-pt)**self.gamma * logpt
        if self.size_average: return loss.mean()
        else: return loss.sum()

class UncertaintyLoss(nn.Module):

    def __init__(self, v_num):
        super(UncertaintyLoss, self).__init__()
        sigma = torch.tensor([1.0,1.0])
        self.sigma = nn.Parameter(sigma)
        self.v_num = v_num

    def forward(self, *input):
        loss = 0
        for i in range(self.v_num):
            loss += input[i] / (2 * self.sigma[i] ** 2)
        loss += torch.log(self.sigma.prod())
        return loss

class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        classifier_dropout = (
            config.classifier_dropout if config.classifier_dropout is not None else config.hidden_dropout_prob
        )
        self.dropout = nn.Dropout(classifier_dropout)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, features, **kwargs):
        x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(x)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x

class ModelWQAHeads(nn.Module):
    def __init__(self,
                 pretrain_hf_model,
                 qa_head_path,
                 layer,
#                  overwrite_config=False,
#                  vocab_size=10000,
#                  max_position_embeddings=512+5,
#                  num_attention_heads=12,
#                  num_hidden_layers=12,
#                  type_vocab_size=1,
#                  hidden_size=768,
#                  num_labels=2,
#                  hidden_dropout_prob=0.1,
#                  attention_probs_dropout_prob=0.5,
#                  position_embedding_type="absolute",
#                  hidden_act="gelu",
                 **kwargs
                 ):
        super(ModelWQAHeads, self).__init__(**kwargs)
        self.layer = layer
        config = AutoConfig.from_pretrained(
            pretrain_hf_model,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
        )
        self.model = RobertaModel.from_pretrained(
            pretrain_hf_model,
            from_tf=False,
            config=config,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
            add_pooling_layer=False
        )
        config = AutoConfig.from_pretrained(
            pretrain_hf_model,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
        )
        self.qa_outputs = nn.Linear(config.hidden_size, config.num_labels).from_Pretrained(qa_head_path)
#         self.qa_outputs = torch.load(f"{qa_head_path}")
        
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        start_positions=None,
        end_positions=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ):
        
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True, return_dict=True)
#         sequence_output = outputs[0]
        hidden_states = outputs.hidden_states[self.layer]
#         logits = self.qa_outputs(hidden_states=sequence_output)
#         start_logits, end_logits = logits.split(1, dim=-1)
#         start_logits = start_logits.squeeze(-1).contiguous()
#         end_logits = end_logits.squeeze(-1).contiguous()
        
#         total_loss = 0
#         if start_positions is not None and end_positions is not None:
#             # If we are on multi-GPU, split add a dimension
#             if len(start_positions.size()) > 1:
#                 start_positions = start_positions.squeeze(-1)
#             if len(end_positions.size()) > 1:
#                 end_positions = end_positions.squeeze(-1)
#             # sometimes the start/end positions are outside our model inputs, we ignore these terms
#             ignored_index = start_logits.size(1)
#             start_positions = start_positions.clamp(0, ignored_index)
#             end_positions = end_positions.clamp(0, ignored_index)

#             loss_fct = CrossEntropyLoss(ignore_index=ignored_index)
#             start_loss = loss_fct(start_logits, start_positions)
#             end_loss = loss_fct(end_logits, end_positions)
#             total_loss = (start_loss + end_loss) / 2
            
            
#         return QuestionAnsweringModelOutput(
#             loss=total_loss,
#             start_logits=start_logits,
#             end_logits=end_logits,
#             hidden_states=outputs.hidden_states,
#             attentions=outputs.attentions,
#         )
        return self.qa_outputs(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            start_positions=start_positions,
            end_positions=end_positions,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            hidden_states=hidden_states,
            device=None,)
    

        
class QAHeads(nn.Module):
    def __init__(self,
                 pretrain_hf_model,
#                  overwrite_config=False,
#                  vocab_size=10000,
#                  max_position_embeddings=512+5,
#                  num_attention_heads=12,
#                  num_hidden_layers=12,
#                  type_vocab_size=1,
#                  hidden_size=768,
#                  num_labels=2,
#                  hidden_dropout_prob=0.1,
#                  attention_probs_dropout_prob=0.5,
#                  position_embedding_type="absolute",
#                  hidden_act="gelu",
                 **kwargs
                 ):
        super(QAHeads, self).__init__(**kwargs)
        config = AutoConfig.from_pretrained(
            pretrain_hf_model,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
        )
        self.qa_outputs = nn.Linear(config.hidden_size, config.num_labels)
        
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        start_positions=None,
        end_positions=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
        hidden_states=None,
        device=None,
    ):
        logits = self.qa_outputs(hidden_states)
        start_logits, end_logits = logits.split(1, dim=-1)
        start_logits = start_logits.squeeze(-1).contiguous()
        end_logits = end_logits.squeeze(-1).contiguous()
        
        total_loss = 0
        if start_positions is not None and end_positions is not None:
            # If we are on multi-GPU, split add a dimension
            if len(start_positions.size()) > 1:
                start_positions = start_positions.squeeze(-1)
            if len(end_positions.size()) > 1:
                end_positions = end_positions.squeeze(-1)
            # sometimes the start/end positions are outside our model inputs, we ignore these terms
            ignored_index = start_logits.size(1)
            start_positions = start_positions.clamp(0, ignored_index)
            end_positions = end_positions.clamp(0, ignored_index)

            loss_fct = CrossEntropyLoss(ignore_index=ignored_index)
            start_loss = loss_fct(start_logits, start_positions)
            end_loss = loss_fct(end_logits, end_positions)
            total_loss = (start_loss + end_loss) / 2
            
            
        return QuestionAnsweringModelOutput(
            loss=total_loss,
            start_logits=start_logits,
            end_logits=end_logits,
            hidden_states=None,
            attentions=None,
        )
    
    def save_pretrained(self, path):
        self.qa_outputs.save_pretrained(path)
        
#     def from_pretrained(self, path):
#         self.qa_outputs.from_pretrained(path)

class Model(nn.Module):
    def __init__(self,
                 pretrain_hf_model,
#                  overwrite_config=False,
#                  vocab_size=10000,
#                  max_position_embeddings=512+5,
#                  num_attention_heads=12,
#                  num_hidden_layers=12,
#                  type_vocab_size=1,
#                  hidden_size=768,
#                  num_labels=2,
#                  hidden_dropout_prob=0.1,
#                  attention_probs_dropout_prob=0.5,
#                  position_embedding_type="absolute",
#                  hidden_act="gelu",
                 **kwargs
                 ):

        super(Model, self).__init__(**kwargs)
#         self.num_labels = num_labels
#         self.config = RobertaConfig(
#             vocab_size=vocab_size,
#             max_position_embeddings=max_position_embeddings,
#             num_attention_heads=num_attention_heads,
#             num_hidden_layers=num_hidden_layers,
#             type_vocab_size=type_vocab_size,
#             hidden_size=hidden_size,
#             num_labels=2,
#             hidden_dropout_prob=hidden_dropout_prob,
#             attention_probs_dropout_prob=attention_probs_dropout_prob,
#             position_embedding_type=position_embedding_type,
#             hidden_act=hidden_act,
#             classifier_dropout=None,
#         )
        config = AutoConfig.from_pretrained(
            pretrain_hf_model,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
        )
        self.model = RobertaModel.from_pretrained(
            pretrain_hf_model,
            from_tf=False,
            config=config,
            cache_dir="./cache",
            revision="main",
            use_auth_token=None,
            add_pooling_layer=False
        )
        self.qa_outputs = nn.Linear(config.hidden_size, config.num_labels)
#         
#         self.init_weights()
#         self.weighted_loss_func = UncertaintyLoss(2)

    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        start_positions=None,
        end_positions=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=True, return_dict=True)
        sequence_output = outputs[0]

        logits = self.qa_outputs(sequence_output)
        start_logits, end_logits = logits.split(1, dim=-1)
        start_logits = start_logits.squeeze(-1).contiguous()
        end_logits = end_logits.squeeze(-1).contiguous()
        
        total_loss = 0
        if start_positions is not None and end_positions is not None:
            # If we are on multi-GPU, split add a dimension
            if len(start_positions.size()) > 1:
                start_positions = start_positions.squeeze(-1)
            if len(end_positions.size()) > 1:
                end_positions = end_positions.squeeze(-1)
            # sometimes the start/end positions are outside our model inputs, we ignore these terms
            ignored_index = start_logits.size(1)
            start_positions = start_positions.clamp(0, ignored_index)
            end_positions = end_positions.clamp(0, ignored_index)

            loss_fct = CrossEntropyLoss(ignore_index=ignored_index)
            start_loss = loss_fct(start_logits, start_positions)
            end_loss = loss_fct(end_logits, end_positions)
            total_loss = (start_loss + end_loss) / 2
            
            
        return QuestionAnsweringModelOutput(
            loss=total_loss,
            start_logits=start_logits,
            end_logits=end_logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
    
#         output = (start_logits, end_logits) + outputs[2:]
#         return ((total_loss,) + output) if total_loss is not None else output
        
    def forward_eval(self, input, labels1=None, labels2=None, device=None):
        input_ids, attention_mask = input
        out = self.model(input_ids=input_ids.to(device), attention_mask=attention_mask.to(device))
        sequence_output = out[0]
        logits1 = self.classifier1(sequence_output)
        logits2 = self.classifier2(sequence_output)

        if labels1 != None:
            loss1 = self.loss_fct(logits1.view(-1, 2), labels1.view(-1))
#             loss2 = self.loss_fct(logits2.view(-1, self.num_labels), labels2.view(-1))
#             loss = self.weighted_loss_func(loss1, loss2)
#             print(loss1, loss2, loss)
#             print("----")
#             exit()
            return loss
        
        else:
            return logits1, logits2

    def get_parameter_number(self):
        #  打印模型参数
        total_num = sum(p.numel() for p in self.parameters())
        trainable_num = sum(p.numel()
                            for p in self.parameters() if p.requires_grad)
        return 'Total parameters: {}, Trainable parameters: {}'.format(total_num, trainable_num)

    def load_weights(self, path):
        if path is not None:
            model_dict = torch.load(path, map_location=torch.device('cpu'))
            self.load_state_dict(model_dict)
            
    def save_pretrained(self, path):
        self.model.save_pretrained(path)
            
            
class MlpBlock(nn.Module):
    def __init__(self, channels):
        super(MlpBlock, self).__init__()

        self.block = nn.Sequential(
            nn.Linear(channels, channels), nn.ReLU(),
            nn.Linear(channels, channels),
        )

    def forward(self, input):
        return input + self.block(input)

def mlp_model_version_1(nmr_input_channels=420, nmr_output_channels=2):

    model = nn.Sequential(
        nn.Linear(nmr_input_channels, nmr_input_channels),
        MlpBlock(nmr_input_channels), nn.Dropout(0.5), nn.ReLU(),
        nn.Linear(nmr_input_channels, nmr_output_channels),
    )
    for m in model.modules():
            if isinstance(m, nn.Linear):
                # print(m.weight.data.type())
                # input()
                # m.weight.data.fill_(1.0)
                nn.init.xavier_uniform_(m.weight, gain=1)
    return model
